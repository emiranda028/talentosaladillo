/** @type {import('next').NextConfig} */
module.exports = {};
