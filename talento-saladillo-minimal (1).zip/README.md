# Talento Saladillo — Minimal

Next.js mínimo para desplegar en Vercel **sin .env ni base**.

## Deploy rápido
1. Subí esta carpeta a un repo de GitHub.
2. Vercel → Add New Project → Importar el repo → Deploy.
3. Abrí la URL: `https://<tu-proyecto>.vercel.app`.

## Desarrollo local
```bash
npm i
npm run dev
```
