import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: { primary:"#2B7A78", secondary:"#17252A", accent:"#3AAFA9", surface:"#FEFFFF" }
    },
  },
  plugins: [],
} satisfies Config;
