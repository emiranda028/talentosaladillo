import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Talento Saladillo",
  description: "Trabajo cerca, talento local",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>
        <header className="bg-secondary text-white">
          <div className="container py-4 flex items-center justify-between">
            <a href="/" className="font-semibold text-xl">Talento Saladillo</a>
            <nav className="flex gap-4 text-sm">
              <a href="/postulantes" className="hover:underline">Postulantes</a>
              <a href="/empresas" className="hover:underline">Empresas</a>
              <a href="/recruiter" className="hover:underline">Recruiter</a>
            </nav>
          </div>
        </header>
        <main className="container py-8">{children}</main>
        <footer className="container py-10 text-sm text-center opacity-70">
          © {new Date().getFullYear()} Talento Saladillo
        </footer>
      </body>
    </html>
  );
}
